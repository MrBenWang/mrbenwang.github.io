﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace MultiLanguageDemo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            LoadLanguage();
        }

        private void LoadLanguage()
        {
            //LanguageManager.Instance.Language = "en-US";
            LanguageManager.Instance.Language = "zh-CN";

            LanguageManager.Instance.Load(lang =>
            {
                var map = new Dictionary<string, LanguageObject>();
                var excel = new ExcelHelper();
                var filePath = $"{AppDomain.CurrentDomain.BaseDirectory}Language.xlsx";
                if (!excel.Open(filePath)) return null;
                excel.Read(map, lang);
                excel.Close();
                return map;
            });
        }
    }
}