﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace MultiLanguageDemo
{
    public class LanguageManager
    {
        public bool IsLangOut { get; set; }
        public string Language { get; set; }

        private string langFile;
        private static LanguageManager _Instance;
        private Dictionary<string, LanguageObject> StrMap;

        public static LanguageManager Instance
        {
            get { return _Instance == null ? _Instance = new LanguageManager() : _Instance; }
        }

        private LanguageManager()
        {
            IsLangOut = false;
            Language = "en_US";
            langFile = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs", "LanguageError.log");
        }

        public bool Load(Func<string, Dictionary<string, LanguageObject>> LoadFile)
        {
            StrMap = LoadFile?.Invoke(Language);
            if (StrMap == null || StrMap.Count == 0) return false;
            else return true;
        }

        public string GetTranslateStr(string key)
        {
            if (string.IsNullOrEmpty(key) || StrMap == null) return string.Empty;
            if (StrMap.ContainsKey(key))
            {
                return StrMap[key].Trans;
            }
            else
            {
                Write2File($"no key: [{key}]\n");
                return key;
            }
        }

        public string TranslateStr(string text)
        {
            if (Language == "en-US" || StrMap == null) return text;

            var lang = StrMap.Values.FirstOrDefault(p => p.English.Trim() == text.Trim());
            if (lang == null)
            {
                Write2File($"can't find value: [{text}]\n");
                return text;
            }
            else
                return lang.Trans;
        }

        public void Write2File(string context)
        {
            if (!IsLangOut) return;
            System.IO.File.AppendAllText(langFile, context, System.Text.Encoding.UTF8);
        }
    }

    public class LanguageObject
    {
        public string English { get; set; }
        public string Trans { get; set; }
    }
}