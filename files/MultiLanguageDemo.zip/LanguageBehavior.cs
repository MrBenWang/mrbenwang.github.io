﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

namespace MultiLanguageDemo
{
    public class LanguageBehavior
    {
        public static readonly DependencyProperty KeyProperty =
            DependencyProperty.RegisterAttached("Key",
                typeof(string), typeof(LanguageBehavior),
                new FrameworkPropertyMetadata(string.Empty, OnKeyChanged));

        private static void OnKeyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            Update(sender, e.NewValue as string);
        }

        public static void SetKey(DependencyObject dp, string value)
        {
            dp.SetValue(KeyProperty, value);
        }

        public static string GetKey(DependencyObject dp)
        {
            return dp.GetValue(KeyProperty) as string;
        }

        public static readonly DependencyProperty ToolTipProperty =
            DependencyProperty.RegisterAttached("ToolTip",
                typeof(string), typeof(LanguageBehavior),
                new FrameworkPropertyMetadata(string.Empty, OnToolTipChanged));

        private static void OnToolTipChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            UpdateToolTip(sender, e.NewValue as string);
        }

        public static void SetToolTip(DependencyObject dp, string value)
        {
            dp.SetValue(ToolTipProperty, value);
        }

        public static string GetToolTip(DependencyObject dp)
        {
            return dp.GetValue(ToolTipProperty) as string;
        }

        private static void Update(DependencyObject sender, string key)
        {
            if (sender is TabItem)
                (sender as TabItem).Header = LanguageManager.Instance.GetTranslateStr(key);
            else if (sender is Label)
                (sender as Label).Content = LanguageManager.Instance.GetTranslateStr(key);
            else if (sender is ContentControl)
                (sender as ContentControl).Content = LanguageManager.Instance.GetTranslateStr(key);
            else if (sender is TextBlock)
                (sender as TextBlock).Text = LanguageManager.Instance.GetTranslateStr(key);
            else if (sender is Run)
                (sender as Run).Text = LanguageManager.Instance.GetTranslateStr(key);
            else if (sender is GridViewColumn)
                (sender as GridViewColumn).Header = LanguageManager.Instance.GetTranslateStr(key);
        }

        private static void UpdateToolTip(DependencyObject sender, string key)
        {
            if (!(sender is FrameworkElement)) return;
            (sender as FrameworkElement).ToolTip = LanguageManager.Instance.GetTranslateStr(key);
        }
    }
}