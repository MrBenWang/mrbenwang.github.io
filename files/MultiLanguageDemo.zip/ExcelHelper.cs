﻿using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace MultiLanguageDemo
{
    public class ExcelHelper
    {
        public static bool IsExcel2007(string fileName)
        {
            var extensin = Path.GetExtension(fileName).ToLower();
            if (extensin == ".xls") return false;
            else if (extensin == ".xlsx") return true;
            else throw new Exception(string.Format("{0}不是Excel文件", fileName));
        }

        public static bool IsExcelFile(string fileName)
        {
            var extensin = Path.GetExtension(fileName).ToLower();
            return (extensin == ".xls" || extensin == ".xlsx");
        }

        private FileStream fstream;
        private IWorkbook workbook;

        public bool Open(string fileName)
        {
            if (!IsExcelFile(fileName)) return false;

            try
            {
                fstream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
                if (fileName.IndexOf(".xlsx") > 0) // 2007版本
                    workbook = new XSSFWorkbook(fstream);
                else //if (fileName.IndexOf(".xls") > 0) // 2003版本
                    workbook = new HSSFWorkbook(fstream);

                if (workbook == null || workbook.NumberOfSheets <= 0) return false;
                return true;
            }
            catch (Exception ex)
            {
                //Logger.LogError(string.Format("ExcelHelper.Open({0}) Exception: {1}", fileName, ex.Message));
                Close();
                return false;
            }
        }

        /// <summary>
        /// 根据 language 来获取 该列的所有翻译文本
        /// </summary>
        /// <param name="map"></param>
        /// <param name="language"></param>
        public void Read(Dictionary<string, LanguageObject> map, string language)
        {
            try
            {
                var index = 0;
                var sheet = workbook.GetSheetAt(0);
                if (sheet == null) return;
                var row = sheet.GetRow(0);
                for (int i = 1; i < row.LastCellNum; ++i)
                {
                    if (GetCellValue(i, row) == language)
                    {
                        index = i;
                        break;
                    }
                }

                for (int i = 1; i <= sheet.LastRowNum; ++i)
                {
                    row = sheet.GetRow(i);
                    if (row == null)
                        return;
                    var key = GetCellValue(0, row);
                    if (map.ContainsKey(key)) continue;
                    var english = GetCellValue(1, row);
                    var trans = (index > 1) ? GetCellValue(index, row) : english;
                    map.Add(key, new LanguageObject() { English = english, Trans = trans });
                }
            }
            catch (Exception ex)
            {
                //Logger.LogError(string.Format("ExcelHelper.Read({0}) Exception: {1}", language, ex.Message));
            }
        }

        public void Close()
        {
            if (workbook != null) workbook.Close();
            if (fstream != null) fstream.Close();
        }

        public ExcelHelper()
        {
            workbook = null;
            fstream = null;
        }

        public static string GetCellValue(ICell cell)
        {
            if (cell == null) return null;
            switch (cell.CellType)
            {
                case CellType.String:
                    return cell.StringCellValue;

                case CellType.Numeric:
                    return cell.DateCellValue.ToString("H:mm:ss");

                case CellType.Boolean:
                    return cell.BooleanCellValue.ToString();

                default:
                    return string.Empty;
            }
        }

        public static string GetCellValue(int column, IRow row)
        {
            return GetCellValue(GetCell(column, row));
        }

        public static ICell GetCell(int column, IRow row)
        {
            var cell = row.GetCell(column);
            return (cell != null) ? cell : row.CreateCell(column);
        }
    }
}