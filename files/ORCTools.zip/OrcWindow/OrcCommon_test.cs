﻿namespace OnenoteOCRDemo
{
    /// <summary>
    /// Main.xaml 的交互逻辑
    /// </summary>
    public partial class Main : Window
    {
        #region 全局变量
        private string __OutputFileName = string.Empty;
        private WebClient client = new WebClient();
        private delegate void UpdateProgressBarDelegate(System.Windows.DependencyProperty dp, Object value);
        #endregion 全局变量

        #region 系统函数
        public Main()
        {
            InitializeComponent();
        }
        #endregion 系统函数

        #region 用户函数
        #region 验证文件夹是否存在，以及是否为空 ：2014-7-10 17:12:57
        //验证文件夹是否存在，以及是否为空
        //时间：2014-7-10 14:54:44
        //作者：白宁超
        private bool fn数据验证()
        {
            if ((bool)this.rbtn本地图片.IsChecked)
            {
                if (!Directory.Exists(this.txtfile.Text))
                {
                    this.labMsg.Content = "目录不存在，重新选择！";
                    this.txtfile.Focus();
                    return true;
                }
                System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(@txtfile.Text);
                if (di.GetFiles().Length + di.GetDirectories().Length == 0)
                {
                    this.labMsg.Content = "目录为空！";
                    this.txtfile.Focus();
                    return true;
                }
            }
            if (!Directory.Exists(this.txt输出目录.Text))
            {
                this.labMsg.Content = "输出目录不存在，请重新选择。";
                this.txt输出目录.Focus();
                return true;
            }

            return false;
        }
        #endregion 验证文件夹是否存在，以及是否为空 ：2014-7-10 17:12:57

        #region 遍历出文件中图片路径
        //文件中选择所有文件处理
        //时间：2014-7-10 17:17:29
        //作者：白宁超
        public List<string> GetImgPath(string Filepath)
        {
            DirectoryInfo d = new DirectoryInfo(Filepath);
            ArrayList Flst = GetAll(d);              //存放图片完整路径

            List<string> imgpath = new List<string>();
            foreach (object o in Flst)
            {
                imgpath.Add(@txtfile.Text + "\\" + o.ToString());
            }
            return imgpath;//返回图片路径集合
        }
        #endregion 遍历出文件中图片路径

        #region 获取图片的过程
        private void fnStartDownload(string v_strImgPath, string v_strOutputDir, out string v_strTmpPath)
        {
            int n = v_strImgPath.LastIndexOf('/');
            string URLAddress = v_strImgPath.Substring(0, n);
            string fileName = v_strImgPath.Substring(n + 1, v_strImgPath.Length - n - 1);
            this.__OutputFileName = v_strOutputDir + "\\" + fileName.Substring(0, fileName.LastIndexOf(".")) + ".txt";

            if (!Directory.Exists(System.Configuration.ConfigurationManager.AppSettings["tmpPath"]))
            {
                Directory.CreateDirectory(System.Configuration.ConfigurationManager.AppSettings["tmpPath"]);
            }

            string Dir = System.Configuration.ConfigurationManager.AppSettings["tmpPath"];
            v_strTmpPath = Dir + "\\" + fileName;
            this.client.DownloadFile(v_strImgPath, v_strTmpPath);
        }
        #endregion 获取图片的过程

        #region//删除指定目录下的所有文件夹以及文件
        private void DelFillOrDir(string strPath)
        {
            if (Directory.GetDirectories(strPath).Length > 0 || Directory.GetFiles(strPath).Length > 0)
            {
                // 获得文件夹数组
                string[] strDirs = System.IO.Directory.GetDirectories(strPath); // 获得文件数组
                string[] strFiles = System.IO.Directory.GetFiles(strPath); // 遍历所有子文件夹
                foreach (string strFile in strFiles)
                {
                    // 删除文件夹
                    System.IO.File.Delete(strFile);
                } // 遍历所有文件
                foreach (string strdir in strDirs)
                { // 删除文件
                    System.IO.Directory.Delete(strdir, true);
                }
            } // 成功
        }
        #endregion 用户函数

        #region//删除文件
        public static bool DeleteFile(string xmlPath)
        {
            FileInfo newFile = new FileInfo(xmlPath);

            if (newFile.Exists == true)
            {
                newFile.Delete();
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region//删除xml数据
        public void DeleteXML(string xpath)
        {
            var onenoteApp = new Microsoft.Office.Interop.OneNote.Application();  //onenote提供的API
            string notebookXml;
            onenoteApp.GetHierarchy(null, Microsoft.Office.Interop.OneNote.HierarchyScope.hsPages, out notebookXml);
            var docc = XDocument.Parse(notebookXml);
            var ns = docc.Root.Name.Namespace;
            XDocument doc = XDocument.Load(xpath);
            string author = "USER-";

            XElement xe = (from db in
                               doc.Element(ns + "Page").Elements(ns + "Outline")
                           where db.Attribute("author").Value == author
                           select db).Single() as XElement;
            try
            {
                xe.Remove();
                doc.Save(xpath);
            }
            catch
            {
            }
        }
        #region  OCR写入Onenote和生成文字整个过程
        //string xpath = @"C:\Users\Administrator\Desktop\OCR_Onenote\OnenoteOCR2.1\tmp.xml";
        private void fnOCR(string v_strImgPath)
        {
            ORC(v_strImgPath);
        }
        public void ORC(string v_strImgPath)
        {
            FileInfo file = new FileInfo(v_strImgPath);
            #region  //获取图片的Base64编码
            using (MemoryStream ms = new MemoryStream())
            {
                Bitmap bp = new Bitmap(v_strImgPath);
                switch (file.Extension.ToLower())
                {
                    case ".jpg":
                        bp.Save(ms, ImageFormat.Jpeg);
                        break;

                    case ".jpeg":
                        bp.Save(ms, ImageFormat.Jpeg);
                        break;

                    case ".gif":
                        bp.Save(ms, ImageFormat.Gif);
                        break;

                    case ".bmp":
                        bp.Save(ms, ImageFormat.Bmp);
                        break;

                    case ".tiff":
                        bp.Save(ms, ImageFormat.Tiff);
                        break;

                    case ".png":
                        bp.Save(ms, ImageFormat.Png);
                        break;

                    case ".emf":
                        bp.Save(ms, ImageFormat.Emf);
                        break;

                    default:
                        this.labMsg.Content = "不支持的图片格式。";
                        return;
                }
                byte[] buffer = ms.GetBuffer();
                string _Base64 = Convert.ToBase64String(buffer);
                #endregion
                //向Onenote2010中插入图片
                var onenoteApp = new Microsoft.Office.Interop.OneNote.Application();  //onenote提供的API
                /***************************************************************************************/
                string sectionID;
                onenoteApp.OpenHierarchy(@"C:\Users\Administrator\Documents\OneNote 笔记本\个人\newfile.one", null, out sectionID, Microsoft.Office.Interop.OneNote.CreateFileType.cftSection);
                string pageID = "{A975EE72-19C3-4C80-9C0E-EDA576DAB5C6}{1}{B0}";
                onenoteApp.CreateNewPage(sectionID, out pageID, Microsoft.Office.Interop.OneNote.NewPageStyle.npsBlankPageNoTitle);
                /********************************************************************************/
                string notebookXml;
                onenoteApp.GetHierarchy(null, Microsoft.Office.Interop.OneNote.HierarchyScope.hsPages, out notebookXml);
                var doc = XDocument.Parse(notebookXml);
                var ns = doc.Root.Name.Namespace;
                var pageNode = doc.Descendants(ns + "Page").FirstOrDefault();
                var existingPageId = pageNode.Attribute("ID").Value;
                #region
                if (pageNode != null)
                {
                    //Image Type 只支持这些类型：auto|png|emf|jpg
                    string ImgExtension = file.Extension.ToLower().Substring(1);
                    switch (ImgExtension)
                    {
                        case "jpg":
                            ImgExtension = "jpg";
                            break;

                        case "png":
                            ImgExtension = "png";
                            break;

                        case "emf":
                            ImgExtension = "emf";
                            break;

                        default:
                            ImgExtension = "auto";
                            break;
                    }

                    #endregion
                    var page = new XDocument(new XElement(ns + "Page",
                                               new XElement(ns + "Outline",
                                                 new XElement(ns + "OEChildren",
                                                   new XElement(ns + "OE",
                                                     new XElement(ns + "Image",
                                                       new XAttribute("format", ImgExtension), new XAttribute("originalPageNumber", "0"),
                                                       new XElement(ns + "Position",
                                                             new XAttribute("x", "0"), new XAttribute("y", "0"), new XAttribute("z", "0")),
                                                       new XElement(ns + "Size",
                                                              new XAttribute("width", bp.Width.ToString()), new XAttribute("height", bp.Height.ToString())),
                                                          new XElement(ns + "Data", _Base64)))))));
                    page.Root.SetAttributeValue("ID", existingPageId);

                    //保存图片进入Onenote页面
                    //注意以下几点：（待解决）
                    //1，onenote页面自动会生成一个页面，可能造成一直ocr错误。删除默认页面，新建空页
                    //2，图片存储在新建页面中，通过如下代码实现的，以追加存储方式进行。
                    onenoteApp.UpdatePageContent(page.ToString(), DateTime.MinValue);

                    //线程休眠时间，单位毫秒，若图片很大，则延长休眠时间，保证Onenote OCR完毕
                    System.Threading.Thread.Sleep(Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["WaitTIme"]));

                    string pageXml;
                    onenoteApp.GetPageContent(existingPageId, out pageXml, Microsoft.Office.Interop.OneNote.PageInfo.piBinaryData);
                    //获取OCR后的内容
                    FileStream tmpXml = new FileStream(System.Configuration.ConfigurationManager.AppSettings["tmpPath"] + @"\tmp.xml", FileMode.Create, FileAccess.ReadWrite);
                    StreamWriter sw = new StreamWriter(tmpXml);
                    sw.Write(pageXml);
                    sw.Flush();
                    sw.Close();
                    tmpXml.Close();
                    //加载xml中的数据
                    FileStream tmpOnenote = new FileStream(System.Configuration.ConfigurationManager.AppSettings["tmpPath"] + @"\tmp.xml", FileMode.Open, FileAccess.ReadWrite);
                    XmlReader reader = XmlReader.Create(tmpOnenote);
                    XElement rdlc = XElement.Load(reader);

                    // rdlc.Save(xpath);

                    /*****************************************************************************************************/
                    XmlNameTable nameTable = reader.NameTable;
                    XmlNamespaceManager mgr = new XmlNamespaceManager(nameTable);
                    mgr.AddNamespace("one", ns.ToString());

                    StringReader sr = new StringReader(pageXml);
                    XElement onenote = XElement.Load(sr);
                    ////读取xml中数据，并保存到文本中。
                    //XDocument doc1 = XDocument.Load(xpath);
                    var xml = from o in onenote.XPathSelectElements("//one:Image", mgr)
                              select o.XPathSelectElement("//one:OCRText", mgr).Value;
                    this.txtOCRed.Text = xml.First().ToString();

                    /**********************************************************************/
                    sr.Close();
                    reader.Close();
                    tmpOnenote.Close();
                    //DeleteXML(xpath);
                    onenoteApp.DeleteHierarchy(existingPageId);
                    //onenoteApp.DeletePageContent(existingPageId, "{242BE490-7BF9-43D5-B719-3999E7631259}{46}{B0}");
                    //onenoteApp.DeletePageContent(existingPageId, "{242BE490-7BF9-43D5-B719-3999E7631259}{50}{B0}");
                }
            }
        }
        #endregion
        #endregion
        #endregion

        #region 系统事件

        #region 搜索文件夹中的文件：2014-7-10 17:12:57
        //搜索文件夹中的文件
        //时间：2014-7-10 14:54:44
        //作者：白宁超
        ArrayList GetAll(DirectoryInfo dir)
        {
            try
            {
                ArrayList FileList = new ArrayList();//定义数组存放图片文件名
                FileInfo[] allFile = dir.GetFiles();
                foreach (FileInfo fi in allFile)
                {
                    FileList.Add(fi.Name);//遍历图片，并添加到数组
                }

                DirectoryInfo[] allDir = dir.GetDirectories();
                foreach (DirectoryInfo d in allDir)
                {
                    GetAll(d);
                }
                return FileList;
            }
            catch (Exception e)
            {
                labMsg.Content = e.Message + "文件夹选择方式错误，重新选择！！";
                return null;
            }
        }
        #endregion

        #region 选择遍历文件夹图片
        //文件中选择所有文件处理
        //时间：2014-7-10 14:54:44
        //作者：白宁超
        private void btn浏览_Click(object sender, RoutedEventArgs e)
        {
            txtmulu.Text = null;
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择待处理目录";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string foldPath = dialog.SelectedPath;
                txtfile.Text = foldPath;
                DirectoryInfo d = new DirectoryInfo(@txtfile.Text);
                ArrayList Flst = GetAll(d);
                foreach (object o in Flst)
                {
                    txtmulu.Text += "正在ORC图片: 【" + o.ToString() + "】\r\n";
                }
            }
            else
            {
                labMsg.Content = "打开失败！！";
            }
            #region 上传单个图片  2014-7-10 15:34:17
            /*OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "请选择一个本地图片";
            ofd.Multiselect = false;
            ofd.Filter = "支持的图片格式(*.jpg,*.jpeg,*.gif,*.bmp,*.png,*.tiff,*.emf)|*.jpg;*.jpeg;*.gif;*.bmp;*.png;*.tiff;*.emf";

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.txt本地图片.Text = ofd.FileName;
                this.img图片.Source = new BitmapImage(new Uri(ofd.FileName, UriKind.RelativeOrAbsolute));

                this.labMsg.Content = "本地图片已成功加载。";
            }*/
            #endregion
        }
        #endregion

        #region  选择本地图片OCR转化
        private void rbtn本地图片_Checked(object sender, RoutedEventArgs e)
        {
            if (this.IsInitialized)
            {
                if ((bool)this.rbtn本地图片.IsChecked)
                {
                    this.txtfile.Text = string.Empty;
                    this.txtfile.IsEnabled = true;
                    this.btn浏览.IsEnabled = true;
                    this.txtfile.Focus();
                    this.txtmulu.Text = null;
                }
            }
        }
        #endregion

        #region  选择需要输入处理的文件
        private void btn浏览_Click_1(object sender, RoutedEventArgs e)
        {
            txtmulu.Text = null;
            FolderBrowserDialog dialog = new FolderBrowserDialog();
            dialog.Description = "请选择待处理目录";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string foldPath = dialog.SelectedPath;
                txtfile.Text = foldPath;
                DirectoryInfo d = new DirectoryInfo(@txtfile.Text);
                ArrayList Flst = GetAll(d);
                foreach (object o in Flst)
                {
                    txtmulu.Text += "正在ORC图片: 【" + o.ToString() + "】\r\n";
                }
            }
            else
            {
                labMsg.Content = "打开失败！！";
            }
            #region 上传单个图片  2014-7-10 15:34:17
            /*OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "请选择一个本地图片";
            ofd.Multiselect = false;
            ofd.Filter = "支持的图片格式(*.jpg,*.jpeg,*.gif,*.bmp,*.png,*.tiff,*.emf)|*.jpg;*.jpeg;*.gif;*.bmp;*.png;*.tiff;*.emf";

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.txt本地图片.Text = ofd.FileName;
                this.img图片.Source = new BitmapImage(new Uri(ofd.FileName, UriKind.RelativeOrAbsolute));

                this.labMsg.Content = "本地图片已成功加载。";
            }*/
            #endregion
        }
        #endregion

        #region 选择输出文件夹
        private void btn输出浏览_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.Description = "请选择一个输出目录";

            if (fbd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.txt输出目录.Text = fbd.SelectedPath;
                DelFillOrDir(this.txt输出目录.Text);
            }
        }

        #endregion

        #region  清空输出文件
        private void btn清空_Click(object sender, RoutedEventArgs e)
        {
            OCRtxt.Text = "";
            this.OCRtxt.Focus();
        }
        #endregion

        #region  ORC转化过程
        private void btnOCR_Click(object sender, RoutedEventArgs e)
        {
            if (this.fn数据验证())
            {
                OCRtxt.Text = "";
                return;
            }
            try
            {
                DirectoryInfo dir = new DirectoryInfo(this.txt输出目录.Text);
                if ((bool)this.rbtn本地图片.IsChecked)
                {
                    List<string> imgpath = GetImgPath(@txtfile.Text);//获取图片列表
                    //定义进度条默认值
                    pb_import.Minimum = 0;
                    pb_import.Maximum = imgpath.Count();
                    double i = 0;

                    txtOCRed.Text = "";
                    OCRtxt.Text += "******************************************************************************";
                    foreach (object img in imgpath)
                    {
                        this.fnOCR(img.ToString());//遍历处理图片orc
                        FileInfo file = new FileInfo(img.ToString());
                        string name = file.Name.Substring(0, file.Name.LastIndexOf("."));
                        this.__OutputFileName = dir.FullName + @"\" + name + ".txt";
                        FileStream fs = new FileStream(this.__OutputFileName, FileMode.Create, FileAccess.ReadWrite);
                        StreamWriter sw = new StreamWriter(fs);
                        sw.Write(this.txtOCRed.Text);//将this.txtOCRed.Text内容写进txt文件中
                        sw.Flush();
                        sw.Close();
                        fs.Close();
                        OCRtxt.Text += "成功ORC出:  【" + name + ".txt】" + "\r\n";

                        //回调UI进度显示
                        i++;
                        pb_import.Value = i;
                        UpdateProgressBarDelegate updatePbDelegate = new UpdateProgressBarDelegate(pb_import.SetValue);
                        Dispatcher.Invoke(updatePbDelegate, System.Windows.Threading.DispatcherPriority.Background, new object[] { System.Windows.Controls.ProgressBar.ValueProperty, Convert.ToDouble(i + 1) });
                        Thread.Sleep(1000);
                    }
                }
                if (pb_import.Value == pb_import.Maximum)
                {
                    System.Windows.Forms.MessageBox.Show("数据转换完成。");
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("数据转换失败。");
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("数据转换失败:" + ex.Message + ex.StackTrace);
                this.labMsg.Content = "OCR失败。";
            }
            finally
            {
                //System.Threading.Thread.CurrentThread.Abort();
                Thread.Sleep(3000);
            }
        }
        #endregion

        #region//窗体关闭
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            DirectoryInfo dir = new DirectoryInfo(System.Configuration.ConfigurationManager.AppSettings["tmpPath"]);
            foreach (FileInfo file in dir.GetFiles())
            {
                file.Delete();
            }
        }
        #endregion

        #endregion
    }
}