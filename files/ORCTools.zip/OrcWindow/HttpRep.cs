﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;

namespace OrcWindow
{
    public partial class HttpRep : Form
    {
        public HttpRep()
        {
            InitializeComponent();
            textBox1.Text = "http://www.cnblogs.com/mvc/blog/GetComments.aspx?postId=2855678&blogApp=kissdodog&pageIndex=0&anchorCommentId=0&_=1474785952212";
            //textBox1.Text = "http://localhost:61802/Service1.svc/GetJsonString";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.IService1 sssss = new ServiceReference1.Service1Client();
            string assss = sssss.GetJsonString();
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(textBox1.Text);
            request.Method = "GET";
            HttpWebResponse response;
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException ex)
            {
                response = (HttpWebResponse)ex.Response;
            }
            StreamReader reader = new StreamReader(response.GetResponseStream());
            string value = reader.ReadToEnd();

            textBox2.Text = value;
        }
    }
}